import { Component } from '@angular/core';
@Component({
  selector : 'criacaodovoto.component',
  styleUrls : ['criacaodovoto.component.scss'],
  templateUrl : 'criacaodovoto.component.html',
})
export class CriacaodoVotoComponent{

}
