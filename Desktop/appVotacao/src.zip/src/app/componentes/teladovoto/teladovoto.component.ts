import { Component } from '@angular/core';
@Component({
  selector : 'teladovoto.component',
  styleUrls : ['teladovoto.component.scss'],
  templateUrl : 'teladovoto.component.html',
})
export class TeladoVotoComponent{
}
