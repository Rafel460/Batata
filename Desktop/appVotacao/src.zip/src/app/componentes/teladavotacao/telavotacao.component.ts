import { Component } from '@angular/core';
@Component({
  selector : 'telavotacao.component',
  styleUrls : ['telavotacao.component.scss'],
  templateUrl : 'telavotacao.component.html',
})
export class TelaVotacaoComponent{
  nome_votacao : String;
  id_votacao : Number;

  mostrarVotacao(){
  }
  }
