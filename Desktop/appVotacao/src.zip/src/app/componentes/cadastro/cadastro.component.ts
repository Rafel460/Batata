import { Component } from '@angular/core';
@Component({
  selector: 'cadastro.component',
  styleUrls : ['cadastro.component.scss'],
  templateUrl : 'cadastro.component.html'
})
export class CadastroComponent{
nome : String;
senha : String;
senha_confirmacao : String;
  cadastrar():void{



  }


}
