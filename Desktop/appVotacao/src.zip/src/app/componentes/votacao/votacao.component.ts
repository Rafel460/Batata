import { Component } from '@angular/core';
@Component({
  selector : 'votacao.component',
  styleUrls : ['votacao.component.scss'],
  templateUrl : 'votacao.component.html',
})
export class VotacaoComponent{

}
