import { Component } from '@angular/core';
@Component({
  selector : 'resultado.component',
  styleUrls : ['resultado.component.scss'],
  templateUrl : 'resultado.component.html',
})
export class ResultadoComponent{

}
