import { Votacao } from './votacao';

describe('Votacao', () => {
  it('should create an instance', () => {
    expect(new Votacao()).toBeTruthy();
  });
});
