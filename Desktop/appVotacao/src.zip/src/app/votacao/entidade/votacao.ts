export class Votacao {
  nome : string;
  id : number;
  opcao_1 : string;
  opcao_2 : string;
  opcao_3 : string;
  senha : string;
}
